#!/bin/sh
# Santa Tracker - Preview [Moment] [Seconds]
. "${SCRIPTDIR:-$(dirname "$0")}/santa_env.sh"
MOMENT="${1:-Santa in my town}"
SECS="${2:-20}"
case "$SECS" in ''|*[!0-9]*) SECS=20 ;; esac
run_bg --once --at "$MOMENT" --seconds "$SECS"
exit 0
