#!/bin/sh
# Santa Tracker - Show Once [Display] [Seconds]
. "${SCRIPTDIR:-$(dirname "$0")}/santa_env.sh"
MODE=$(mode_opt "$1")
SECS="${2:-20}"
case "$SECS" in ''|*[!0-9]*) SECS=20 ;; esac
run_bg --once $MODE --seconds "$SECS"
exit 0
