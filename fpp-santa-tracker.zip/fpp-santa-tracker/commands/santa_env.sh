# Shared setup for the Santa Tracker command scripts.
# fppd runs these with almost no environment (no PATH), and waits for them
# to finish, so every script starts Python in the background and returns.
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
CMDDIR="${SCRIPTDIR:-$(dirname "$0")}"
PLUGINDIR="$(cd "$CMDDIR/.." && pwd)"
export MEDIADIR="${MEDIADIR:-/home/fpp/media}"
LOGFILE="$MEDIADIR/logs/plugin-fpp-santa-tracker.log"
ENGINE="$PLUGINDIR/santa_tracker.py"
export SANTA_QUIET=1

# "Map" / "Text" / "Map then text" -> engine option
mode_opt() {
    case "$1" in
        Map) echo "--mode=map" ;;
        Text) echo "--mode=text" ;;
        "Map then text") echo "--mode=both" ;;
        *) echo "" ;;
    esac
}

# run the engine detached from fppd
run_bg() {
    setsid python3 "$ENGINE" "$@" </dev/null >/dev/null 2>>"$LOGFILE" &
}
