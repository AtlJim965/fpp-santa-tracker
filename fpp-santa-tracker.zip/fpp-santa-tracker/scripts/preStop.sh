#!/bin/bash
# Stop the display before fppd stops.
PLUGINDIR="$(cd "$(dirname "$0")/.." && pwd)"
MEDIADIR="${MEDIADIR:-/home/fpp/media}"
MEDIADIR="$MEDIADIR" timeout 8 /usr/bin/python3 "$PLUGINDIR/santa_tracker.py" --stop >/dev/null 2>&1 || true
exit 0
