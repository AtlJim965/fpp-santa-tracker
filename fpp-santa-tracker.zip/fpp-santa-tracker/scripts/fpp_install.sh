#!/bin/bash
# Santa Tracker - install / reinstall (runs as root; safe to run again).
PLUGINDIR="$(cd "$(dirname "$0")/.." && pwd)"
MEDIADIR="${MEDIADIR:-/home/fpp/media}"
OWNER="$(stat -c '%U:%G' "$MEDIADIR" 2>/dev/null || echo fpp:fpp)"

mkdir -p "$MEDIADIR/plugindata/fpp-santa-tracker" "$MEDIADIR/images"
chown "$OWNER" "$MEDIADIR/plugindata/fpp-santa-tracker" || true
chmod 755 "$PLUGINDIR/santa_tracker.py" "$PLUGINDIR"/commands/*.sh \
          "$PLUGINDIR"/scripts/*.sh 2>/dev/null || true

# FPP only picks up a plugin's commands when fppd starts.
if [ -f "${FPPDIR:-/opt/fpp}/scripts/common" ]; then
    . "${FPPDIR:-/opt/fpp}/scripts/common"
    setSetting restartFlag 1 2>/dev/null || true
fi
echo "Santa Tracker installed. Restart FPPD to load its commands."
exit 0
