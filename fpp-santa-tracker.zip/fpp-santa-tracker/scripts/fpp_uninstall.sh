#!/bin/bash
# Santa Tracker - uninstall (runs as root; safe to run twice).
PLUGINDIR="$(cd "$(dirname "$0")/.." && pwd)"
MEDIADIR="${MEDIADIR:-/home/fpp/media}"
MEDIADIR="$MEDIADIR" timeout 15 /usr/bin/python3 "$PLUGINDIR/santa_tracker.py" --stop >/dev/null 2>&1 || true
pkill -f "$PLUGINDIR/santa_tracker.py" 2>/dev/null || true
rm -f "$MEDIADIR"/images/santa_map_*.png
rm -rf "$MEDIADIR/plugindata/fpp-santa-tracker"
# Your settings (config/plugin.fpp-santa-tracker) are kept for a reinstall.
exit 0
