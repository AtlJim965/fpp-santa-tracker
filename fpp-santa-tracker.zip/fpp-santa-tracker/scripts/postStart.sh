#!/bin/bash
# Start the display after fppd starts, if "Start automatically" is on.
PLUGINDIR="$(cd "$(dirname "$0")/.." && pwd)"
MEDIADIR="${MEDIADIR:-/home/fpp/media}"
CFG="$MEDIADIR/config/plugin.fpp-santa-tracker"
if grep -Eq '^AutoStart *= *"?1"?' "$CFG" 2>/dev/null; then
    # give fppd a few seconds to finish loading the overlay models
    ( sleep 10; MEDIADIR="$MEDIADIR" SANTA_QUIET=1 setsid /usr/bin/python3 \
        "$PLUGINDIR/santa_tracker.py" --loop </dev/null >/dev/null \
        2>>"$MEDIADIR/logs/plugin-fpp-santa-tracker.log" ) &
fi
exit 0
